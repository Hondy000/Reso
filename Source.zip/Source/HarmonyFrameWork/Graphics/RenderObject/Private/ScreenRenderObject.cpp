
#include "../Public/ScreenRenderObject.h"
#include "../../Buffer/Public/VertexBuffer.h"
#include "../Public/SubMesh.h"
#include "../Public/BaseRenderObject.h"
#include "../../../ResorceManager/Public/BasicMeshManager.h"
using namespace  std;

ScreenRenderObject::ScreenRenderObject()
{
}

ScreenRenderObject::~ScreenRenderObject()
{
}

bool ScreenRenderObject::Init()
{
	return true;
}

