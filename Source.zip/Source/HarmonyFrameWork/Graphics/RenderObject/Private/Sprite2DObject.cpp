#include "../Public/Sprite2DObject.h"
#include "../../Public/RenderCommand.h"
#include "../../../Core/Task/Public/TaskSystem.h"


bool Sprite2DObject::Init()
{
	

	return true;
}

bool Sprite2DObject::Update()
{

	std::shared_ptr<RenderCommand> command;
	command = std::shared_ptr<RenderCommand>(new RenderCommand);
	command->SetRenderObject(StaticMeshObject::shared_from_this());
	TaskSystem::GetInstance()->RegisterRenderCommand(command);
	return true;
}

