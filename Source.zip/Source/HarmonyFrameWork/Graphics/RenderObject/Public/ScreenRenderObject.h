#pragma once
#include "Sprite2DObject.h"

class ScreenRenderObject
	:
	public Sprite2DObject
{
public:
	ScreenRenderObject();
	~ScreenRenderObject();
	bool Init();
private:

};
