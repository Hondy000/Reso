#pragma once
#include "../../RenderObject/Public/BaseRenderObject.h"

class BaseParticle
	:
	public BaseRenderObject
{
public:
	BaseParticle()
	{
	};

	virtual~BaseParticle()
	{
	};

private:

};
