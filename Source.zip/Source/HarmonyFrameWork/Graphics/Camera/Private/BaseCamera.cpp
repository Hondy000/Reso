/**********************************************************************************************//**
 * @file	Source\HarmonyFrame\Graphics\GraphicsObject\Basic\CBaseCamera.cpp
 *
 * @brief	Implements the base camera class.
 **************************************************************************************************/

#include "../Public/BaseCamera.h"

#include "../../RenderDevice/Basic/Public/RendererManager.h"

/**********************************************************************************************//**
  * @fn	bool CBaseCamera::Setup(void)
  *
  * @brief	Gets the setup.
  *
  * @author	Kazuyuki Honda
  * @date	2015/11/04
  *
  * @return	A bool.
  **************************************************************************************************/


BaseCamera::BaseCamera()
{
	Init();
}

bool BaseCamera::Init(void)
{
	HRESULT hr = E_FAIL;
	m_aspect = sRENDER_DEVICE_MANAGER->GetScreenSize().y / sRENDER_DEVICE_MANAGER->GetScreenSize().x;
	m_cameraPosition = HFVECTOR3(0.0f, 0.0f, -40.0f);
	m_farClip = 10000.0f;
	m_nearClip = 1;
	m_upVector = HFVECTOR3(0.0f, 1.0f, 0.0f);
	m_viewAngle = HF_PI / 3.0f;
	m_viewVector = HFVECTOR3(0.0f, 0.00f, 1.0f);
	m_distanceFromFollowTarget = { 0,0,-40 };
	m_rotation.x = (0);
	m_rotation.y = (0);
	m_rotation.z = (0);
	return true;
}

/**********************************************************************************************//**
 * @fn	bool CBaseCamera::Draw(void)
 *
 * @brief	Draws this object.
 *
 * @author	Kazuyuki Honda
 * @date	2015/11/04
 *
 * @return	true if it succeeds, false if it fails.
 **************************************************************************************************/

bool BaseCamera::Update(void)
{
	HFMATRIX view, proj;

	UpdateViewMatrix();
	UpdateProjectionMatrix();

	return true;
}

void BaseCamera::UpdateViewMatrix()
{
	HFMATRIX view;	
	HFVECTOR3 up, position, lookAt;
	{
		position = m_cameraPosition;
	}

	float yaw, pitch, roll;
	HFMATRIX rotationMatrix;

	// Setup the std::vector that points upwards.
	up.x = 0.0f;
	up.y = 1.0f;
	up.z = 0.0f;

	
	//
	lookAt.x = 0.0f;
	lookAt.y = 0.0f;
	lookAt.z = 1.0f;

	// Set the yaw (Y axis), pitch (X axis), and roll (Z axis) rotations in radians.
	pitch = HFToRadian(m_rotation.x);
	yaw = HFToRadian(m_rotation.y);
	roll = HFToRadian(m_rotation.z);

	// Create the rotation matrix from the yaw, pitch, and roll values.
	HFMatrixRotationYawPitchRoll(&rotationMatrix, yaw, pitch, roll);

	// �x�N�g������]������
	HFVec3TransformCoord(&lookAt, &lookAt, &rotationMatrix);
	HFVec3TransformCoord(&up, &up, &rotationMatrix);

	// �ʒu+�����x�N�g���Œ����_�����߂�
	lookAt += position;
	

	HFMatrixLookAtLH(&view, &position, &lookAt, &up);
	sRENDER_DEVICE_MANAGER->SetTransform(&view, HFTS_VIEW);
}

void BaseCamera::UpdateProjectionMatrix()
{
	HFMATRIX  proj;

	// �������e�̐ݒ�
	HFMatrixPerspectiveLH(
		&proj,
		m_viewAngle,
		m_aspect,
		m_nearClip,
		m_farClip);

	sRENDER_DEVICE_MANAGER->SetTransform(&proj, HFTS_PERSPECTIVE );
}