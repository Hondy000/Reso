#pragma once
#include "../../../../../Core/Public/Common.h"
class CDirectX11DeviceContext
{
public:
	CDirectX11DeviceContext();
	~CDirectX11DeviceContext();
	bool Init(void);
protected:
	Microsoft::WRL::ComPtr<ID3D11DeviceContext>m_D3DDeviceContext;        // Direct3D11 �f�o�C�X�R���e�L�X�g�B
};
