/**********************************************************************************************//**
 * @file	Source\HarmonyFrame\Graphics\Renderer\DirectX\ver.11\CDirectX11Adapter.cpp
 *
 * @brief	Implements the direct x coordinate 11 adapter class.
 **************************************************************************************************/

#include "../Public/CDirectX11Adapter.h"

/**********************************************************************************************//**
  * @fn	CDirectX11Adapter::CDirectX11Adapter()
  *
  * @brief	Default constructor.
  *
  * @author	Kazuyuki Honda
  * @date	2015/08/02
  **************************************************************************************************/

CDirectX11Adapter::CDirectX11Adapter()
{
}

/**********************************************************************************************//**
 * @fn	CDirectX11Adapter::~CDirectX11Adapter()
 *
 * @brief	Destructor.
 *
 * @author	Kazuyuki Honda
 * @date	2015/08/02
 **************************************************************************************************/

CDirectX11Adapter::~CDirectX11Adapter()
{
}

/**********************************************************************************************//**
 * @fn	bool CDirectX11Adapter::Setup()
 *
 * @brief	Initialises this object.
 *
 * @author	Kazuyuki Honda
 * @date	2015/08/02
 *
 * @return	A bool.
 **************************************************************************************************/

bool CDirectX11Adapter::Setup()
{
	HRESULT hr = E_FAIL;
	return hr;
}

/**********************************************************************************************//**
 * @fn	bool CDirectX11Adapter::CreateAdapter()
 *
 * @brief	�f�t�H���g�A�_�v�^�[�̃C���^�[�t�F�[�X���쐬����.
 *
 * @author	Kazuyuki Honda
 * @date	2015/08/02
 *
 * @return	The new adapter.
 **************************************************************************************************/

bool CDirectX11Adapter::CreateAdapter()
{
	HRESULT hr = E_FAIL;
	IDXGIFactory* pFactory = NULL;

	if (m_cpAdapter == NULL)
	{
		// �t�@�N�g�����쐬����B
		// CreateDXGIFactory
		hr = CreateDXGIFactory(__uuidof(IDXGIFactory), (void**)(&pFactory));
		if (FAILED(hr)) goto EXIT;

		// �f�t�H���g�A�_�v�^�[���擾
		// IDXGIFactory::EnumAdapters
		hr = pFactory->EnumAdapters(0, m_cpAdapter.GetAddressOf());
		if (FAILED(hr)) goto EXIT;
	}

	hr = S_OK;
EXIT:
	SAFE_RELEASE(pFactory);

	return hr;
}

/**********************************************************************************************//**
 * @fn	void CDirectX11Adapter::ReleaseAdapter(void)
 *
 * @brief	Releases the adapter.
 *
 * @author	Kazuyuki Honda
 * @date	2015/08/02
 **************************************************************************************************/

void CDirectX11Adapter::ReleaseAdapter(void)
{
	m_cpAdapter.Detach();
}