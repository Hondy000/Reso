#pragma once
#include "../../../Core/Public/IBaseObject.h"

class BaseShaderResourceView
	:
	public IBaseObject
{
	BaseShaderResourceView() {};
	virtual ~BaseShaderResourceView() {};


};
