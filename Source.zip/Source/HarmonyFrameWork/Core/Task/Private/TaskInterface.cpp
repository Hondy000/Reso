
#include "../Public/TaskInterface.h"

bool IBaseTask::Init()
{
	m_taskId = std::hash<IBaseTask*>()(this);

	return true;
}

bool IBaseTask::LoadTaskData(const std::string& path)
{
	return false;
}

