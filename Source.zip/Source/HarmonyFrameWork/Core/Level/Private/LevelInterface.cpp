
#include "../Public/LevelInterface.h"

using namespace std;
IBaseLevel::IBaseLevel()
{

}

IBaseLevel::~IBaseLevel()
{

}

bool IBaseLevel::Init()
{
	RegisterVariable("m_isChangeLevel", false);
	CreateVariable("m_changeLevelName", typeid(string).name());
	
	return true;
}

bool IBaseLevel::IsChangeLevel()
{
	return *GetVariable<bool>("m_isChangeLevel")->GetValue();
}

const std::string& IBaseLevel::GetChangeLevelType(void)
{
	return *GetVariable<string>("m_changeLevelName")->GetValue();
}

void IBaseLevel::SetChangeLevelType(const std::string& changeLevelType)
{
	GetVariable<string>("m_changeLevelName")->SetValue(changeLevelType);
}

