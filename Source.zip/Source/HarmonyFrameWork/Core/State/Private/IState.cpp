
#include "../Public/IState.h"
IState::IState()
	:m_isChangeState(false)
{

}


IState::~IState()
{

}

