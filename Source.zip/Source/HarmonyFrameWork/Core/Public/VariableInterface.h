﻿#pragma once
#include "Common.h"

enum VariableType
{
	VAR_TYPE_S8,	/*!< An enum constant representing the variable type signed 8 bit option */
	VAR_TYPE_U8,	/*!< An enum constant representing the variable type unsigned 8 bit option */
	VAR_TYPE_S16,   /*!< An enum constant representing the variable type signed 16 bit option */
	VAR_TYPE_U16,   /*!< An enum constant representing the variable type unsigned 16 bit option */
	VAR_TYPE_S32,   /*!< An enum constant representing the variable type sigend 32 bit option */
	VAR_TYPE_U32,   /*!< An enum constant representing the variable type unsigned 32 bit option */
	VAR_TYPE_F32,   /*!< An enum constant representing the variable type float 32 bit option */
	VAR_TYPE_F64,   /*!< An enum constant representing the variable type flaot 64 bit option */
	VAR_TYPE_BOOL,  /*!< An enum constant representing the variable type bool option */
	VAR_TYPE_VEC2,  /*!< An enum constant representing the variable type vector 2 dimensional option */
	VAR_TYPE_VEC3,  /*!< An enum constant representing the variable type vector 3 dimensional option */
	VAR_TYPE_VEC4,		// An enum constant representing the variable type vector 4 dimensional option */
	VAR_TYPE_MAT44, /*!< An enum constant representing the variable type matrix float 4x4 option */
	VAR_TYPE_QUATERNION,	/*!< An enum constant representing the variable type quaternion option */
	VAR_TYPE_STR,   /*!< An enum constant representing the variable type string option */
	VAR_TYPE_HFBASE_CUSTOM,	/*!< An enum constant representing the variable type custom option */
	VAR_TYPE_UNKNOWN,   /*!< An enum constant representing the variable type unknown option */
	VAR_TYPE_MAX	/*!< An enum constant representing the variable type maximum option */
};


// 先行宣言
class IVariable;

// VariableInterfase演算用関数
bool Equality(std::shared_ptr<IVariable>, std::shared_ptr<IVariable>);

IVariable Add(std::shared_ptr<IVariable> iVariable, std::shared_ptr<IVariable> sharedPtr);

IVariable Subtruct(std::shared_ptr<IVariable> iVariable, std::shared_ptr<IVariable> sharedPtr);

IVariable Multi(std::shared_ptr<IVariable> iVariable, std::shared_ptr<IVariable> sharedPtr);


IVariable Division(std::shared_ptr<IVariable> iVariable, std::shared_ptr<IVariable> sharedPtr);

template<typename T>
bool Equality(std::shared_ptr<IVariable>iVariable, T var);

template<typename T>
IVariable Add(std::shared_ptr<IVariable> iVariable, T var);

template<typename T>
IVariable Subtruct(std::shared_ptr<IVariable> iVariable, T var);

class IVariable
	:
	public inheritable_enable_shared_from_this<IVariable>
{
public:
	IVariable() {};
	IVariable(IVariable& var)
	{
	
	};
	virtual~IVariable() {};


			   /*
	virtual bool operator== (IVariable& var)
	{

		return Equality(this->shared_from_this(), var.shared_from_this());
	}


	template<typename T>
	bool operator == (T var)
	{
		return Equality(this->shared_from_this(), var);
	}


	virtual IVariable operator + (IVariable& var)
	{
		return Add(this->shared_from_this(), var.shared_from_this());
	}
	template<typename T>
	IVariable operator + (T var)
	{
		return Add(this->shared_from_this(), var);
	}



	template<typename T>
	void operator = (T var)
	{
		Equal(this->shared_from_this(), var);
	}
				 */
	// Access the VariableType
	VariableType GetVariableType(void) const
	{
		return(m_variableType);
	};
	void SetVariableType(const VariableType& variableType)
	{
		m_variableType = variableType;
	};

	

protected:


	VariableType m_variableType;
}; 



template <class T>
class Variable
	:
	public IVariable
{
public:
	// Access the Name
	const std::string& GetName(void) const	{ return(m_name);	};
	void SetName(const std::string& name)	{ m_name = name;	};


	// Access the Value
	std::shared_ptr<T> GetValue(void)
	{
		return(m_value);
	};
	void SetValue(std::shared_ptr<T>& value)
	{
		m_value = value;
	};

	void SetValue(T value)
	{
		if (m_value)
		{
			*m_value = value;
		}
		else
		{
			m_value = std::make_shared<T>();
			*m_value = value;
		}
	};

private:

	std::string m_name;
	std::shared_ptr<T> m_value;
};


template <class T>
class VariableArray
	:
	public IVariable
{
public:



	// Access the Name
	const std::string& GetName(void) const { return(m_name); };
	void SetName(const std::string& name) { m_name = name; };

	// Access the Array
	const std::vector<std::shared_ptr<T>>& GetArray(void) const	{ return(m_array);	};
	void SetArray(const std::vector<std::shared_ptr<T>>& array)	{ m_array = array;	};

private:

	std::string m_name;
	std::vector<std::shared_ptr<T>> m_array;
};

