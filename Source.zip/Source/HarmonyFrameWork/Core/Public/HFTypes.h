﻿#ifndef _INCLUDE_HFTYPES_HEADDER_
#define _INCLUDE_HFTYPES_HEADDER_

#ifdef DIRECTX11
#include "DirectX11Types.h"
#endif // DIRECTX11
#endif