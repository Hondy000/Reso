#include "..\Public\Sprite2DActor.h"
Sprite2DActor::Sprite2DActor()
{
}

Sprite2DActor::~Sprite2DActor()
{
}

bool Sprite2DActor::Init()
{
	return Sprite2DObject::Init();
}

void Sprite2DActor::Reset()
{

}

bool Sprite2DActor::Update()
{
	return Sprite2DObject::Update();
}
