#include "..\Public\StaticMeshActor.h"
#include "../../../ResorceManager/Public/MeshManager.h"

StaticMeshActor::StaticMeshActor()
{
}

StaticMeshActor::~StaticMeshActor()
{
}

bool StaticMeshActor::Init()
{
	return false;
}

bool StaticMeshActor::Update()
{
	StaticMeshObject::Update();
	UpdateAllTask();
	return true;
}

void StaticMeshActor::Reset()
{

}


bool StaticMeshActor::LoadMesh(const std::string& path)
{
	m_mesh = MeshManager::GetInstance()->Get(path);
	if (m_mesh)
	{
		return S_OK;
	}
	return E_FAIL;
}