#include "..\Public\SpawnActor.h"

SpawnActor::SpawnActor()
{

}

SpawnActor::~SpawnActor()
{
}

bool SpawnActor::Init()
{

	return true;
}

void SpawnActor::Reset()
{

}

bool SpawnActor::Update()
{

	return true;
}

