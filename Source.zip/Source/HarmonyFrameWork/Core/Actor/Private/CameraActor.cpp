#include "..\Public\CameraActor.h"

bool CameraActor::Init()
{
	return true;
}

bool CameraActor::Update()
{
	BaseCamera::Update();
	return true;
}

