﻿#include "../public/VariableInterface.h"
