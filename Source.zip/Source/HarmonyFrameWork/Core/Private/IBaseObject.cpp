/**********************************************************************************************//**
 * @file	Source\HarmonyFrame\Basic\CBaseObject.cpp
 *
 * @brief	Implements the base object class.
 **************************************************************************************************/

#include "../Public/IBaseObject.h"

bool IBaseObject::Init()
{
	return true;
}
