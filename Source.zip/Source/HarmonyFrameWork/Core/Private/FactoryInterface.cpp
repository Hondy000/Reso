﻿#include "../Public/FactoryInterface.h"

namespace Factorys
{
	std::list<IObjectFactory*> FactorysManager::m_pFactoryList;
}
