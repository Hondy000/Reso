﻿#include "../Public/ManagerInterface.h"

std::list<IObjectManager*> ObjectManagersManager::m_pManagerList;
