#include "..\Public\StaticMeshCompornent.h"
#include "..\..\..\ResorceManager\Public\MeshManager.h"
#include "..\..\..\Graphics\RenderObject\Public\StaticMeshObject.h"

using namespace std;

bool StaticMeshCompornent::Init()
{
	return true;
};

bool StaticMeshCompornent::LoadMesh(const string& path)
{
	m_mesh = MeshManager::GetInstance()->Get(path);
	return S_OK;

}

bool StaticMeshCompornent::Update()
{

	StaticMeshObject::Update();
	return true;
}

