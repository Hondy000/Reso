
#include "../Public/CameraCompornent.h"

CameraCompornent::CameraCompornent()
{

}

CameraCompornent::~CameraCompornent()
{

}

bool CameraCompornent::Update()
{			  
	m_camera->Update();
	return true;
}

