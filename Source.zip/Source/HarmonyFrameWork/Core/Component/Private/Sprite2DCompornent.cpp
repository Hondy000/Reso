
#include "../Public/Sprite2DCompornent.h"

Sprite2DCompornent::Sprite2DCompornent()
{

}

Sprite2DCompornent::~Sprite2DCompornent()
{

}

bool Sprite2DCompornent::Init()
{
	return Sprite2DObject::Init();
}

void Sprite2DCompornent::Reset()
{

}

bool Sprite2DCompornent::Update()
{
	return Sprite2DObject::Update();
}

void Sprite2DCompornent::Destroy()
{

}

