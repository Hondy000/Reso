#pragma once
#include "../../../Graphics/Camera/Public/BaseCamera.h"
#include "CompornentInterface.h"

class CameraCompornent
	:
	public ICompornent
{
public:
	CameraCompornent();
	~CameraCompornent();
	void Destroy() {};
	bool Init()
	{
		m_camera = std::make_shared<BaseCamera>();
		return true;
	};
	void Reset() {};
	bool Update();

private:
	std::shared_ptr<BaseCamera> m_camera;
};
