#include "../Public/Title.h"
#include "../Public/TitleStates.h"

bool Title::Init()
{
	return false;
}

bool Title::Update()
{
	return true;
}

void Title::Reset()
{

}
