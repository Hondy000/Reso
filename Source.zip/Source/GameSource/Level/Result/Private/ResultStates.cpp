
#include "../Public/ResultStates.h"

ResultMainState::ResultMainState()
{
}

ResultMainState::~ResultMainState()
{
}