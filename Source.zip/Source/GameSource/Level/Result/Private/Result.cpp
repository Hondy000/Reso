#include "..\Public\Result.h"

bool Result::Init()
{
	return true;
}

bool Result::Update()
{
	return true;

}

void Result::Reset()
{

}

