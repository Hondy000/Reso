#pragma once

class ResultMainState
{
public:
	ResultMainState();
	~ResultMainState();

private:

};
