#pragma once
#include "../Public/EnemyManager.h"

EnemyManagerActor::EnemyManagerActor()
{
}

EnemyManagerActor::~EnemyManagerActor()
{
}