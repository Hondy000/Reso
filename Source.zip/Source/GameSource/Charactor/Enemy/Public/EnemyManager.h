#pragma once

class EnemyManagerActor
{
public:
	EnemyManagerActor();
	~EnemyManagerActor();
	bool Init();
	void Reset();
	bool Update();


private:

};
