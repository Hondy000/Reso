#include "../Public/PlayerActor.h"
#include "../../../../HarmonyFrameWork/Core/Component/Public/StaticMeshCompornent.h"
#include "../../../../HarmonyFrameWork/Core/Task/Public/TaskSystem.h"
#include "../../../../HarmonyFrameWork/Core/Component/Public/CameraCompornent.h"
#include "../Public/PlayerStates.h"

using namespace std;

bool PlayerActor::Init()
{
	CharactorActor::Init();
	shared_ptr<CameraCompornent> cameraCompornent = make_shared<CameraCompornent>();
	cameraCompornent->Init();
	RegisterCompornent(typeid(CameraCompornent).name() , cameraCompornent);
	auto it = m_compornentMap.find(typeid(StaticMeshCompornent).name());
	if(it != m_compornentMap.end())
	{
		if(dynamic_pointer_cast<StaticMeshCompornent>(it->second)->LoadMesh("Resource/Mesh/Sphere.hfm"))
		{
		}
	}
	
	RegisterState(std::make_shared<PlayerAliveBeingState>(),shared_from_this());
	return true;
}

bool PlayerActor::Update()
{
	UpdateState(shared_from_this());
	UpdateAllTask();
	return true;

}

void PlayerActor::Reset()
{

}
