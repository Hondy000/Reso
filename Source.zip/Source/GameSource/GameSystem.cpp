/**********************************************************************************************//**
 * @file	CGameMain.cpp
 *
 * @brief	Implements the game main class.
 **************************************************************************************************/

#include "GameSystem.h"
#include "..\HarmonyFrameWork\Input\Public\InputManager.h"
#include "..\HarmonyFrameWork\Graphics\RenderDevice\Basic\Public\RendererManager.h"
#include "..\HarmonyFrameWork\Core\Task\Public\TaskSystem.h"
bool GameSystem::isEnd = 0;

/**********************************************************************************************//**
 * @fn	CGameMain::CGameMain()
 *
 * @brief	Default constructor.
 *
 * @author	Kazuyuki
 * @date	2015/06/17
 **************************************************************************************************/

bool GameSystem::Update()
{
	return true;
}


void GameSystem::Reset()
{
}

GameSystem::GameSystem()
{
}

/**********************************************************************************************//**
 * @fn	CGameMain::~CGameMain()
 *
 * @brief	Destructor.
 *
 * @author	Kazuyuki
 * @date	2015/06/17
 **************************************************************************************************/

GameSystem::~GameSystem()
{
}

/**********************************************************************************************//**
 * @fn	void CGameMain::Init(bool isFull,int width,int height)
 *
 * @brief	Initialises this object.
 *
 * @author	Kazuyuki Honda
 * @date	2015/06/30
 *
 * @param	isFull	true if this object is full.
 * @param	width 	The width.
 * @param	height	The height.
 **************************************************************************************************/

bool GameSystem::Init()
{
	m_levelManager = std::make_shared<LevelManager>();
	RendererManager::GetInstance()->Setup();
	sRENDER_DEVICE_MANAGER->Setup();
	InputManager::GetInstance()->Setup();
	sINPUT->Setup();
	m_levelManager->Init();

	return true;
}

/**********************************************************************************************//**
 * @fn	void CGameMain::GameMain(void)
 *
 * @brief	Game main.
 *
 * @author	Kazuyuki
 * @date	2015/06/17
 **************************************************************************************************/

void GameSystem::TransitionState()
{
	
}

void GameSystem::GameMain(void)
{
	sTASK_SYSTEM->Update();
	sTASK_SYSTEM->Render();
}
